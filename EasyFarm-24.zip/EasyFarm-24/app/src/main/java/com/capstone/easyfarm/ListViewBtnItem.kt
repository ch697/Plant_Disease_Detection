package com.capstone.easyfarm

class ListViewBtnItem {
    var MyPlant_image_URL: String = ""
    var MyPlant_Pest: String = ""
    var MyPlant_Percentage: Double = 0.0
    var MyPlant_Date: String = ""
}