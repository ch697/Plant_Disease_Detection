package com.capstone.easyfarm

data class DataModel (

    val date : String = "",
    val memo : String = ""

)